package Controller_Components;

public class AuthCtlr {
    boolean Enabled; // If this variable reports a value of true, Authorization is enabled
    int AdditionalInfoItemsPerMessage ; //Maximum number of AdditionalInfo items that can be sent in one message
    boolean OfflineTxForUnknownIdEnabled; // If this key exists, the Charging Station supports Unknown Offline Authorization.
    boolean AuthorizeRemoteStart;//Whether a remote request to start a transaction in the form of
    //RequestStartTransactionRequest message should be authorized beforehand like
    //a local action to start a transaction.
    boolean LocalAuthorizeOffline; // Whether the Charging Station, when Offline, will start a transaction for locallyauthorized identifiers.
    boolean LocalPreAuthorize; // Whether the Charging Station, when online, will start a transaction for locallyauthorized
    // identifiers without waiting for or requesting an AuthorizeResponse from the CSMS.
    String MasterPassGroupId; // IdTokens that have this id as groupId belong to the Master Pass Group.



}
