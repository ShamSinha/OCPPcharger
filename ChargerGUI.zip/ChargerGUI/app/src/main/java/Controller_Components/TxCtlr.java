package Controller_Components;

import com.example.chargergui.TxStartStopPoint;

public class TxCtlr {

    boolean ChargingBeforeAcceptedEnabled ; //allow charging before accepting BootNotificationResponse with Registration status Accepted
    int EVConnectionTimeOut ; // in seconds
    boolean StopTxOnEVSideDisconnect;
    boolean TxBeforeAcceptedEnabled ;
    int MaxEnergyOnInvalidId ; // in Wh
    boolean StopTxOnInvalidId ;
    TxStartStopPoint TxStartPoint ;
    TxStartStopPoint TxStopPoint ;

    public boolean isChargingBeforeAcceptedEnabled() {
        return ChargingBeforeAcceptedEnabled;
    }

    public void setChargingBeforeAcceptedEnabled(boolean chargingBeforeAcceptedEnabled) {
        ChargingBeforeAcceptedEnabled = chargingBeforeAcceptedEnabled;
    }

    public int getEVConnectionTimeOut() {
        return EVConnectionTimeOut;
    }

    public void setEVConnectionTimeOut(int EVConnectionTimeOut) {
        this.EVConnectionTimeOut = EVConnectionTimeOut;
    }

    public boolean isStopTxOnEVSideDisconnect() {
        return StopTxOnEVSideDisconnect;
    }

    public void setStopTxOnEVSideDisconnect(boolean stopTxOnEVSideDisconnect) {
        StopTxOnEVSideDisconnect = stopTxOnEVSideDisconnect;
    }

    public boolean isTxBeforeAcceptedEnabled() {
        return TxBeforeAcceptedEnabled;
    }

    public void setTxBeforeAcceptedEnabled(boolean txBeforeAcceptedEnabled) {
        TxBeforeAcceptedEnabled = txBeforeAcceptedEnabled;
    }

    public int getMaxEnergyOnInvalidId() {
        return MaxEnergyOnInvalidId;

    }

    public void setMaxEnergyOnInvalidId(int maxEnergyOnInvalidId) {
        MaxEnergyOnInvalidId = maxEnergyOnInvalidId;
    }

    public boolean isStopTxOnInvalidId() {
        return StopTxOnInvalidId;
    }

    public void setStopTxOnInvalidId(boolean stopTxOnInvalidId) {
        StopTxOnInvalidId = stopTxOnInvalidId;
    }

    public TxStartStopPoint getTxStartPoint() {
        return TxStartPoint;
    }

    public void setTxStartPoint(TxStartStopPoint txStartPoint) {
        TxStartPoint = txStartPoint;
    }

    public TxStartStopPoint getTxStopPoint() {
        return TxStopPoint;
    }

    public void setTxStopPoint(TxStartStopPoint txStopPoint) {
        TxStopPoint = txStopPoint;
    }
}


