package Controller_Components;

import EnumDataType.MessageFormatEnumType;
import EnumDataType.MessagePriorityEnumType;

public class DisplayMessageCtrlr {
    boolean Enabled;
    boolean Available;
    int DisplayMessages ; //Amount of different messages that are currently configured in this Charging Station, via SetDisplayMessageRequest.
    int PersonalMessageSize ;
    MessageFormatEnumType SupportedFormats;
}
