package EnumDataType;

public enum IdTokenEnumType {
    Central, eMAID , ISO14443,KeyCode ,Local ,NoAuthorization ,ISO15693 ;
}
