package EnumDataType;

public enum DataTransferStatusEnumType {
    Accepted, Rejected , UnknownMessageId , UnknownVendorId ;

}
