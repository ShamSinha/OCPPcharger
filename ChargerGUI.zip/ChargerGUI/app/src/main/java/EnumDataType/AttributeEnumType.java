package EnumDataType;

public enum AttributeEnumType {
    Actual ,Target , MinSet , MaxSet ;
}
