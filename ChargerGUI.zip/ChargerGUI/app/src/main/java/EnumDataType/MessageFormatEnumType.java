package EnumDataType;

public enum MessageFormatEnumType {
    ASCII , HTML , URI , UTF8 ;
}
