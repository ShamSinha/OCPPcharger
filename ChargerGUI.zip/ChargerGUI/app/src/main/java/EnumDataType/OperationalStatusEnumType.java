package EnumDataType;

public enum OperationalStatusEnumType {
    Inoperative , //Charging Station is not available for charging.
    Operative //Charging Station is available for charging
}
