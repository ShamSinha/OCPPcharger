package EnumDataType;

public enum  TxStopPoint {
    EVConnected
}
