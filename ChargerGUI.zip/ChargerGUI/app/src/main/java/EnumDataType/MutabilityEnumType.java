package EnumDataType;

public enum MutabilityEnumType {
    ReadOnly , WriteOnly , ReadWrite ;
}
