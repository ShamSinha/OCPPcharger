package EnumDataType;

public enum TxStartPoint {
   EVConnected , Authorized
}

