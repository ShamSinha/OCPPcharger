package EnumDataType;

public enum DisplayMessageStatusEnumType {
    Accepted , NotSupportedMessageFormat , Rejected ,NotSupportedPriority , NotSupportedState , UnknownTransaction ;

}
