package EnumDataType;

public enum ConnectorStatusEnumType {
    Available , Occupied, Reserved , Unavailable , Faulted ;
}
