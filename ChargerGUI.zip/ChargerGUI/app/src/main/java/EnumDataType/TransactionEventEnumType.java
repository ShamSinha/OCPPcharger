package EnumDataType;

public enum TransactionEventEnumType {
    Ended, // Last event of a transaction
    Started , //First event of a transaction.
    Updated ; // Transaction event in between 'Started' and 'Ended'.
}
