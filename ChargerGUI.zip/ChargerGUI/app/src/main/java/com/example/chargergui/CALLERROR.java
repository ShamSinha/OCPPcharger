package com.example.chargergui;

import org.json.JSONObject;

public class CALLERROR extends WebsocketMessage {

    private final String ErrorCode ;
    private final String ErrorDescription ;
    private final JSONObject ErrorDetails ;

    public CALLERROR(int MessageTypeId, String MessageId, String ErrorCode ,String ErrorDescription ,JSONObject ErrorDetails){

        this.MessageTypeId = MessageTypeId ;
        this.MessageId = MessageId ;
        this.ErrorCode = ErrorCode ;
        this.ErrorDescription = ErrorDescription ;
        this.ErrorDetails = ErrorDetails ;
    }

    public String getErrorCode(){
        return this.ErrorCode ;
    }
    public String getErrorDescription(){
        return this.ErrorDescription ;
    }
    public JSONObject getErrorDetails() {
        return this.ErrorDetails ;}

}
