package com.example.chargergui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.widget.ProgressBar;

import android.os.Bundle;

import java.io.IOException;

public class Authorization2 extends AppCompatActivity {
    ProgressBar progressBar ;
    String rfid;
    boolean stopThread ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rfid_auth);
        progressBar =(ProgressBar) findViewById(R.id.pb);
        progressBar.setEnabled(false);

        final MainActivity bs = new MainActivity();

        if(bs.BTinit()){
            if(bs.BTconnect()){
                bs.deviceConnected=true;
                final Handler handler = new Handler();
                stopThread = false;

                Thread thread  = new Thread(new Runnable()
                {
                    public void run()
                    {
                        while(!Thread.currentThread().isInterrupted() && !stopThread)
                        {
                            try
                            {
                                String string = "getRFID";
                                bs.outputStream.write(string.getBytes());

                                int byteCount = bs.inputStream.available();
                                if(byteCount > 0)
                                {
                                    byte[] mmBuffer = new byte[1024];
                                    int numBytes; // bytes returned from read()
                                    numBytes = bs.inputStream.read(mmBuffer);
                                    final String ch=new String(mmBuffer,"UTF-8");
                                    handler.post(new Runnable() {
                                        public void run()
                                        {
                                            rfid = ch ;
                                        }
                                    });

                                }
                            }
                            catch (IOException ex)
                            {
                                stopThread = true;
                            }
                        }
                    }
                });

                thread.start();
            }
        }


    }
}
