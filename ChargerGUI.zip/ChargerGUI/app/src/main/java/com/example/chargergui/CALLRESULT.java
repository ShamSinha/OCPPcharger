package com.example.chargergui;

import org.json.JSONObject;


public class CALLRESULT extends WebsocketMessage {

    private final JSONObject Payload ;

    public CALLRESULT(int MessageTypeId, String MessageId,JSONObject Payload){

        this.MessageTypeId = MessageTypeId ;
        this.MessageId = MessageId ;
        this.Payload = Payload ;
    }

    JSONObject getPayload() { return this.Payload ;}
}