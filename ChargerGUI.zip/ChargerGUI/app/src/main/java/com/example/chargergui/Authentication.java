package com.example.chargergui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Authentication extends AppCompatActivity {

    ImageButton pin ;
    ImageButton rfid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);
        pin = (ImageButton) findViewById(R.id.imageButtonpin);
        rfid =(ImageButton) findViewById(R.id.imageButtonrfid);

        pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Authentication.this, Authorization1.class);

                startActivity(i);
            }
        });
        rfid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Authentication.this, Authorization2.class);

                startActivity(i);
            }
        });

    }
}
