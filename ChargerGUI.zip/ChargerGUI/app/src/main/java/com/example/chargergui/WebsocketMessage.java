package com.example.chargergui;

public class WebsocketMessage {
    int MessageTypeId ;
    String MessageId ;

    public int getMessageTypeId(){
        return this.MessageTypeId ;
    }
    public String getMessageId(){
        return this.MessageId ;
    }
}

