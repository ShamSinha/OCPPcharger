package com.example.chargergui;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Logger;

import javax.websocket.ClientEndpoint ;
import javax.websocket.ContainerProvider;
import javax.websocket.DeploymentException;
import javax.websocket.EncodeException;
import javax.websocket.OnOpen ;
import javax.websocket.OnClose ;
import javax.websocket.OnMessage ;
import javax.websocket.OnError ;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import javax.websocket.Decoder;
import javax.websocket.Encoder ;

import ChargingStationRequest.BootNotificationRequest;
import ChargingStationResponse.CostUpdatedResponse;
import ChargingStationResponse.ReserveNowResponse;
import ChargingStationResponse.ResetResponse;
import ChargingStationResponse.SetDisplayMessageResponse;

@ClientEndpoint(
        decoders = {MessageDecoder.class},
        encoders = {MessageEncoder.class,MessageEncodeResult.class , MessageEncodeError.class},
        subprotocols = {"ocpp2.0.1"},
        configurator = ClientConfigurator.class
)

public class MyClientEndpoint  {
    private Session session = null;
    public MyClientEndpoint(URI uri) throws IOException, DeploymentException, URISyntaxException {
        ContainerProvider.getWebSocketContainer().connectToServer(this,uri);
        session.getId();

    }


    @OnOpen
    public void onOpen(Session session){
        this.session = session ;

    }


    @OnMessage
    public void onMessage(WebsocketMessage msg, Session session) throws JSONException, IOException, EncodeException {
        if(msg instanceof CALL){
            JSONObject payload = null ;

            switch (((CALL) msg).getAction() ) {
                case "CostUpdated":
                    CostUpdatedResponse costUpdatedResponse = new CostUpdatedResponse();
                    payload = costUpdatedResponse.payload();
                    break;
                case "SetDisplayMessage":
                    SetDisplayMessageResponse setDisplayMessageResponse = new SetDisplayMessageResponse();
                    payload = setDisplayMessageResponse.payload();
                    break;
                case "Reset":
                    ResetResponse resetResponse = new ResetResponse();
                    payload = resetResponse.payload();
                    break;
                /*case "ReserveNow" :
                    ReserveNowResponse reserveNowResponse = new ReserveNowResponse();
                    payload = reserveNowResponse.payload();
                    break;*/

            }
            CALLRESULT callresult = new CALLRESULT(3,((CALL) msg).getMessageId(),payload);
            session.getBasicRemote().sendObject(callresult);
        }
        if (msg instanceof CALLRESULT){
            String s = ((CALLRESULT) msg).getMessageId() ;

        }
        if (msg instanceof CALLERROR){

        }


    }


    }







}
