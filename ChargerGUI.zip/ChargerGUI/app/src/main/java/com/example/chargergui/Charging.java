package com.example.chargergui;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Charging extends AppCompatActivity {
    ImageView BatteryCharge ;
    Button stopCharging;
    TextView voltage;
    TextView current ;
    TextView TimeRemaining;
    TextView Charge ;
    TextView Miles ;
    Button WantToChargeMore ;
    TextView textTime ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charging);

        BatteryCharge = (ImageView) findViewById(R.id.imageViewcharge);
        final float SOC = 15;
        ImageChargeBattery imageChargeBattery = new ImageChargeBattery(SOC,BatteryCharge);

        voltage = (TextView) findViewById(R.id.voltage) ;
        current = (TextView) findViewById(R.id.current);
        Charge = (TextView ) findViewById(R.id.charge) ;
        Miles = (TextView) findViewById(R.id.miles) ;
        TimeRemaining = (TextView) findViewById(R.id.remain);
        textTime = (TextView) findViewById(R.id.textTime);

        WantToChargeMore.setVisibility(View.INVISIBLE);

        stopCharging = (Button) findViewById(R.id.stopbutton);
        WantToChargeMore = (Button) findViewById(R.id.button4);



        stopCharging.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                ImageSetBattery imageSetBattery = new ImageSetBattery(SOC,BatteryCharge);
                stopCharging.setVisibility(View.GONE);
                voltage.setVisibility(View.GONE);
                current.setVisibility(View.GONE);
                textTime.setText(R.string.totaltime);

            }
        });


    }



}
