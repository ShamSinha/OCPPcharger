package com.example.chargergui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView ;
import android.view.View ;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import UseCasesOCPP.SendRequestToCSMS;


public class Authorization1 extends AppCompatActivity {
    EditText PIN ;
    TextView dateTime ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authorization1);
        PIN = (EditText) findViewById(R.id.enterpin);
        dateTime =(TextView) findViewById(R.id.date_time) ;
        dateTime2 dT = new dateTime2();
        dateTime.setText(dT.dateTime());





        final Button button = (Button) findViewById(R.id.authorize);
        button.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Assert")
            public void onClick(View v) {
                // Perform action on click

                SendRequestToCSMS request = new SendRequestToCSMS()
                if (PIN.getText().toString().equals("1234")){



                    Intent i = new Intent(Authorization1.this, UserInput.class);
                    startActivity(i);
                    Toast.makeText(getApplicationContext(), "Authorization Successful" , Toast.LENGTH_SHORT).show();

                }

                else {
                    Toast.makeText(getApplicationContext(), "PIN is incorrect\n Try Again!" , Toast.LENGTH_SHORT).show();
                }

                }
            });




        }


    }
