package com.example.chargergui;

import org.json.JSONObject;


public class CALL extends WebsocketMessage{


    private final  String Action ;
    private final JSONObject Payload ;

    public CALL(int MessageTypeId, String MessageId, String Action,JSONObject Payload){
        this.MessageTypeId = MessageTypeId ;
        this.MessageId = MessageId ;
        this.Action = Action ;
        this.Payload = Payload ;
    }

    public String getAction(){
        return this.Action ;
    }
    public JSONObject getPayload() { return this.Payload ;}
}