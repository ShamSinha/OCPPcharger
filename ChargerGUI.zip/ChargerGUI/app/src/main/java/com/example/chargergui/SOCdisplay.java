package com.example.chargergui;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;

import android.widget.ImageView;
import android.widget.TextView ;
import android.view.View ;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SOCdisplay extends AppCompatActivity {
    TextView Batterytype;
    TextView Charge ;
    TextView dateTime ;
    TextView Recommendation ;
    ImageView battery ;
    String chargeValue ;
    public float standardrate = 4;
    public float semifastrate = 5;
    public float fastrate = 8;

    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socdisplay);
        Batterytype = (TextView) findViewById(R.id.batterytype);
        Charge = (TextView) findViewById(R.id.charge);
        battery = (ImageView) findViewById(R.id.imageView) ;

        Calendar calendar = Calendar.getInstance();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:sss");
        String date = df.format(calendar.getTime());
        dateTime =(TextView) findViewById(R.id.date_time) ;
        dateTime.setText(date);

        final MainActivity bs = new MainActivity();

        if(bs.BTinit()){
            if(bs.BTconnect()){
                bs.deviceConnected=true;
                final Handler handler = new Handler();

                Thread thread  = new Thread(new Runnable()
                {
                    public void run()
                    {
                        boolean stopThread ;
                        stopThread = false ;
                        while(!Thread.currentThread().isInterrupted() && !stopThread)
                        {
                            try
                            {
                                String string = "current_SOC";
                                bs.outputStream.write(string.getBytes());

                                int byteCount = bs.inputStream.available();
                                if(byteCount > 0)
                                {
                                    byte[] mmBuffer = new byte[1024];
                                    int numBytes; // bytes returned from read()
                                    numBytes = bs.inputStream.read(mmBuffer);
                                    final String ch=new String(mmBuffer,"UTF-8");
                                    handler.post(new Runnable() {
                                        public void run()
                                        {
                                            chargeValue = ch ;

                                            ImageSetBattery imagesetBattery = new ImageSetBattery(Float.parseFloat(ch),battery);

                                            String e = getEnergy(Float.parseFloat(ch),getBatteryCapacity());

                                            Charge.setText(String.format("%s%% Charge / %s Wh ", ch,e));
                                        }
                                    });

                                }
                            }
                            catch (IOException ex)
                            {
                                stopThread = true;
                            }
                        }
                    }
                });

                thread.start();
            }
        }



        Recommendation = (TextView) findViewById(R.id.recommend) ;
        Recommendation.setText(R.string.hh);

        final Button Standard = (Button) findViewById(R.id.standard);
        final Button Semi_Fast = (Button) findViewById(R.id.semi);
        final Button Fast = (Button) findViewById(R.id.fast);
        Standard.setText(String.format("STANDARD CHARGING /  Rs. %s/KWhr",String.valueOf(standardrate)));
        Semi_Fast.setText(String.format("SEMI-FAST CHARGING / Rs. %s/KWhr",String.valueOf(semifastrate)));
        Fast.setText(String.format("FAST CHARGING / Rs. %s/KWhr",String.valueOf(fastrate)));


        Standard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(SOCdisplay.this, UserInput.class);
                i.putExtra("ch", chargeValue);
                i.putExtra("rate",String.format("STANDARD CHARGING\n / Rs. %s/KWhr",String.valueOf(standardrate)));
                // currentContext.startActivity(activityChangeIntent);
                startActivity(i);
            }
        });

        Semi_Fast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SOCdisplay.this, UserInput.class);
                i.putExtra("ch", chargeValue);
                i.putExtra("rate",String.format("SEMI-FAST CHARGING\n / Rs. %s/KWhr",String.valueOf(semifastrate)));

                // currentContext.startActivity(activityChangeIntent);
                startActivity(i);
            }
        });

        Fast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SOCdisplay.this, UserInput.class);
                i.putExtra("ch", chargeValue);
                i.putExtra("rate",String.format("FAST CHARGING\n / Rs. %s/KWhr",String.valueOf(fastrate)));

                // currentContext.startActivity(activityChangeIntent);
                startActivity(i);
            }
        });

    }
    public int getBatteryCapacity(){
        return 60000; //Wh
    }

    public String getEnergy(float soc , int BatteryCapacity){
        float Energy = (soc*BatteryCapacity)/100 ;
        return String.valueOf(Energy) ;
    }
}
