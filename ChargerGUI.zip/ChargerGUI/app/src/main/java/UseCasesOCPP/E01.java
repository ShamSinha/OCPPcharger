package UseCasesOCPP;

import com.example.chargergui.CALL;

import org.json.JSONException;

import ChargingStationRequest.TransactionEventRequest;
import DataType.EVSEType;
import DataType.IdTokenType;
import DataType.TransactionType;
import EnumDataType.ChargingStateEnumType;
import EnumDataType.TransactionEventEnumType;
import EnumDataType.TriggerReasonEnumType;
import EnumDataType.TxStartPoint;
public class E01 {
    private TransactionEventRequest transactionEventRequest;


    public E01(String transactionId, TxStartPoint t , IdTokenType idTokenType , EVSEType evse) throws JSONException {

        TransactionType transactionType;

        if(t == TxStartPoint.EVConnected){
            transactionType = new TransactionType(transactionId, ChargingStateEnumType.EVConnected,0,null);
            transactionEventRequest = new TransactionEventRequest(TransactionEventEnumType.Started, TriggerReasonEnumType.CablePluggedIn,false, transactionType,idTokenType,evse);
        }
        if(t == TxStartPoint.Authorized){
            transactionType = new TransactionType(transactionId, ChargingStateEnumType.EVConnected,0,null);
            transactionEventRequest = new TransactionEventRequest(TransactionEventEnumType.Started, TriggerReasonEnumType.Authorized,false, transactionType,idTokenType,evse);
        }

        UUIDgenerator uuiDgenerator = new UUIDgenerator();
        CALL call = new CALL(2,uuiDgenerator.uuid(),"Authorize",transactionEventRequest.payload()) ;
    }
}
