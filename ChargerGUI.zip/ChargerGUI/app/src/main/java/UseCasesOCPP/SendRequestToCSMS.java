package UseCasesOCPP;

import com.example.chargergui.CALL;
import com.example.chargergui.TransactionIdGenerator;

import org.json.JSONException;

import java.io.IOException;
import java.util.UUID;

import javax.websocket.EncodeException;
import javax.websocket.Session;

import ChargingStationRequest.AuthorizeRequest;
import ChargingStationRequest.BootNotificationRequest;
import ChargingStationRequest.HeartBeatRequest;
import ChargingStationRequest.StatusNotificationRequest;
import ChargingStationRequest.TransactionEventRequest;
import DataType.ChargingStationType;
import DataType.IdTokenType;
import DataType.TransactionType;
import EnumDataType.BootReasonEnumType;
import EnumDataType.ChargingStateEnumType;
import EnumDataType.ConnectorStatusEnumType;
import EnumDataType.IdTokenEnumType;
import EnumDataType.TransactionEventEnumType;
import EnumDataType.TriggerReasonEnumType;

public class SendRequestToCSMS {

    private Session session ;
    public SendRequestToCSMS(Session session){
        this.session = session ;
    }

    public void sendBootNotificationRequest() throws JSONException, IOException, EncodeException {
        CALL call = new CALL(2, UUID.randomUUID().toString(),"BootNotification",BootNotificationRequest.payload());
        this.session.getBasicRemote().sendObject(call);
    }

    public void sendStatusNotificationRequest(int evseId , int connectorId, ConnectorStatusEnumType connectorStatus) throws IOException, EncodeException, JSONException {
        StatusNotificationRequest.setEvseId(evseId);
        StatusNotificationRequest.setConnectorId(connectorId);
        StatusNotificationRequest.setConnectorStatus(connectorStatus);
        StatusNotificationRequest.setTimestamp();
        CALL call = new CALL(2,UUID.randomUUID().toString(),"StatusNotification",StatusNotificationRequest.payload());
        this.session.getBasicRemote().sendObject(call);
    }

    public void sendHeartBeatRequest() throws JSONException, IOException, EncodeException {
        CALL call = new CALL(2,UUID.randomUUID().toString(),"HeartBeat",HeartBeatRequest.payload());
        this.session.getBasicRemote().sendObject(call);
    }

    public void sendAuthorizeRequest(IdTokenEnumType idTokenEnumType, String idToken) throws JSONException, IOException, EncodeException {
        IdTokenType.setIdToken(idToken);
        IdTokenType.setType(idTokenEnumType);
        CALL call = new CALL(2,UUID.randomUUID().toString(),"Authorize",AuthorizeRequest.payload()) ;
        this.session.getBasicRemote().sendObject(call);
    }

    public void sendTransactionEventRequest(TransactionEventEnumType eventType ) throws JSONException, IOException, EncodeException {
        TransactionType.setTransactionId(TransId(eventType));

        CALL call = new CALL(2, UUID.randomUUID().toString(), "TransactionEvent", TransactionEventRequest.payload());
        session.getBasicRemote().sendObject(call);

        }


    public static String TransId(TransactionEventEnumType transactionEventEnumType){
        if(transactionEventEnumType == TransactionEventEnumType.Started){
            TransactionIdGenerator.setTransactionId();
            return TransactionIdGenerator.transactionId ;
        }
        if(transactionEventEnumType == TransactionEventEnumType.Updated){
            return TransactionIdGenerator.transactionId ;
        }
        if(transactionEventEnumType == TransactionEventEnumType.Ended){
            return TransactionIdGenerator.transactionId ;
        }

        return null;
    }

}
