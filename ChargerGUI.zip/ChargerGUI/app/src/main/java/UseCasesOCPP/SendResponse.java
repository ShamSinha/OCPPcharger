package UseCasesOCPP;

import com.example.chargergui.CALL;
import com.example.chargergui.WebsocketMessage;

public class SendResponse {

    public SendResponse(CALL call){

    }
}
