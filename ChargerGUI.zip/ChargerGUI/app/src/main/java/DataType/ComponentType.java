package DataType;

import DataType.EVSEType;

public class ComponentType {
    String name ;
    String instance ;
    EVSEType evse ;

}
