package DataType;

import EnumDataType.DataEnumType;

public class VariableCharacteristicsType {
    String unit ;
    DataEnumType dataType ;
    float minLimit ;
    float maxLimit ;

}
