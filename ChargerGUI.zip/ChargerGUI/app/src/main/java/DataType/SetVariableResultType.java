package DataType;

import EnumDataType.AttributeEnumType;

import EnumDataType.SetVariableStatusEnumType;

public class SetVariableResultType {
    private AttributeEnumType attributeType ;
    private SetVariableStatusEnumType attributeStatus ;
    private ComponentType component ;
    private VariableType variable ;

    public SetVariableResultType(AttributeEnumType attributeType, SetVariableStatusEnumType attributeStatus, ComponentType component, VariableType variable) {
        this.attributeType = attributeType;
        this.attributeStatus = attributeStatus;
        this.component = component;
        this.variable = variable;
    }

    public AttributeEnumType getAttributeType() {
        return attributeType;
    }

    public SetVariableStatusEnumType getAttributeStatus() {
        return attributeStatus;
    }

    public ComponentType getComponent() {
        return component;
    }

    public VariableType getVariable() {
        return variable;
    }


}
