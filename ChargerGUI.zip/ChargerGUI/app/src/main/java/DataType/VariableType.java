package DataType;

public class VariableType {
    String name ;
    String instance ;

}
