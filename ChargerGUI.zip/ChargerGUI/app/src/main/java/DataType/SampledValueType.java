package DataType;

import EnumDataType.MeasurandEnumType;
import EnumDataType.ReadingContextEnumType;

public class SampledValueType {
    float value;  // Indicates the measured value.
    ReadingContextEnumType context;
    MeasurandEnumType measurand;
    UnitOfMeasureType unitOfMeasure;

    public SampledValueType(float value, ReadingContextEnumType context, MeasurandEnumType measurand, UnitOfMeasureType unitOfMeasure) {
        this.value = value;
        this.context = context;
        this.measurand = measurand;
        this.unitOfMeasure = unitOfMeasure;
    }
}