package DataType;

import EnumDataType.MessageFormatEnumType;

import java.util.LinkedHashMap;
import java.util.Map;

public class MessageContentType {
    private MessageFormatEnumType format ;
    private String language ;
    private String content ;

    public MessageContentType(MessageFormatEnumType format, String language, String content) {
        this.format = format;
        this.language = language;
        this.content = content;
    }

    private MessageFormatEnumType getFormat() {
        return format;
    }

    private String getLanguage() {
        return language;
    }

    public String getContent() {
        return content;
    }


    Map getp(){

        Map<String, String> m = new LinkedHashMap<String, String>(3);
        m.put("format",getFormat().toString());
        m.put("language", getLanguage()) ;
        m.put("content",getContent());

        return m ;
    }

}

