package DataType;

import EnumDataType.AuthorizationStatusEnumType;
import com.example.chargergui.dateTime2;

import java.util.LinkedHashMap;
import java.util.Map;

public class IdTokenInfoType {
    private AuthorizationStatusEnumType status ;
    private String cacheExpiryDateTime ;
    private int chargingPriority ;
    private MessageContentType personalMessage ;

    public IdTokenInfoType(AuthorizationStatusEnumType status, String cacheExpiryDateTime, int chargingPriority, MessageContentType personalMessage) {
        this.status = status;
        this.cacheExpiryDateTime = cacheExpiryDateTime;
        this.chargingPriority = chargingPriority;
        this.personalMessage = personalMessage;
    }

    private AuthorizationStatusEnumType getStatus() {
        return status;
    }

    private String getCacheExpiryDateTime() {
        return cacheExpiryDateTime;
    }

    private int getChargingPriority() {
        return chargingPriority;
    }

    public MessageContentType getPersonalMessage() {
        return personalMessage;
    }


    // map for json payload
    Map getp1() {
        Map<String, String> m = new LinkedHashMap<String, String>(4);
        m.put("status", getStatus().toString());
        m.put("cacheExpiryDateTime", getCacheExpiryDateTime());
        m.put("chargingPriority", String.valueOf(getChargingPriority()));
        return m;

    }
    Map getp2() {
        Map<String, Map> t = new LinkedHashMap<String, Map>(1);
        MessageContentType messageContent = new MessageContentType();
        t.put("personalMessage", messageContent.getp());
        return t;
    }



}
