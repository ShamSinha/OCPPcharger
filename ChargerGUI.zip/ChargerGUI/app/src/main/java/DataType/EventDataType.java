package DataType;

import EnumDataType.EventTriggerEnumType;
import com.example.chargergui.dateTime;

public class EventDataType {
    int eventId ;
    dateTime timestamp ;
    String actualValue ;
    EventTriggerEnumType trigger ;

}
