package DataType;

import EnumDataType.MessagePriorityEnumType;
import EnumDataType.MessageStateEnumType;
import com.example.chargergui.dateTime;

public class MessageInfoType {
    int id ;
    MessagePriorityEnumType priority ;
    MessageStateEnumType state ;
    dateTime startDateTime ;
    dateTime endDataTime ;
    String transactionId ;
    MessageContentType message ;
    ComponentType display ;

}
