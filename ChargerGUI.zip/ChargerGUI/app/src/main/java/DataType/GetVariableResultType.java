package DataType;

import EnumDataType.AttributeEnumType;

import EnumDataType.GetVariableStatusEnumType;

public class GetVariableResultType {
    GetVariableStatusEnumType attributeStatus ;
    AttributeEnumType attributeType ;
    String attributeValue ;
    ComponentType component ;
    VariableType variable ;


}
