package DataType;

public class MessageType {


}
