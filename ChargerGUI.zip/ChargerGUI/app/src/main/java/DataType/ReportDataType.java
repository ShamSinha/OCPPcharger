package DataType;

public class ReportDataType {
    ComponentType component ;
    VariableType variable ;
    VariableAttributeType variableAttribute ;
    VariableCharacteristicsType variableCharacteristics ;

}
