package DataType;

public class ModemType {
    String iccid;
    String imsi ;

}
