package DataType;

import EnumDataType.AttributeEnumType;
import EnumDataType.MutabilityEnumType;

public class VariableAttributeType {
    AttributeEnumType type ;
    String value ;
    MutabilityEnumType mutability ;
    boolean persistent ;
    boolean constant ;
}
