package DataType;

import java.util.LinkedHashMap;
import java.util.Map;

public class EVSEType {
    private static int id = 0;  // This contains a number (> 0) designating an EVSE of the Charging Station
    private static int connectorId  = 0; // An id to designate a specific connector (on an EVSE) by connector index number.

    public static void setId(int id) {
        EVSEType.id = id;
    }

    public static void setConnectorId(int connectorId) {
        EVSEType.connectorId = connectorId;
    }

    public static int getId() {
        return id;
    }

    public static Map getp(){
        Map<String, String> m = new LinkedHashMap<String, String>(2);
        m.put("id", String.valueOf(EVSEType.id));
        m.put("connectorId", String.valueOf(EVSEType.connectorId)) ;
        return m ;
    }
}
