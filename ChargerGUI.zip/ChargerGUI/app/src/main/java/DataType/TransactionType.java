package DataType;

import ChargingStationRequest.TransactionEventRequest;
import EnumDataType.ChargingStateEnumType;
import EnumDataType.ReasonEnumType;
import EnumDataType.TransactionEventEnumType;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class TransactionType {
    public static String transactionId = null ;
    public static ChargingStateEnumType chargingState = ChargingStateEnumType.Idle ;
    public static int timeSpentCharging = 0 ;
    public static ReasonEnumType stoppedReason = null;

    public static void setTransactionId(String transactionId) {
        TransactionType.transactionId = transactionId;
    }

    public static void setChargingState(ChargingStateEnumType chargingState) {
        TransactionType.chargingState = chargingState;
    }

    public static void setTimeSpentCharging(int timeSpentCharging) {
        TransactionType.timeSpentCharging = timeSpentCharging;
    }

    public static void setStoppedReason(ReasonEnumType stoppedReason) {
        TransactionType.stoppedReason = stoppedReason;
    }

    public static Map getp() {
        Map<String, String> i = new LinkedHashMap<String, String>(4);
        i.put("transactionId", TransactionType.transactionId);
        if (TransactionType.chargingState!= null) {
            i.put("chargingState", TransactionType.chargingState.toString());
        }
        if(TransactionType.timeSpentCharging!= 0) {
            i.put("timeSpentCharging", String.valueOf(TransactionType.timeSpentCharging));
        }
        if(TransactionType.stoppedReason!= null) {
            i.put("stoppedReason",TransactionType.stoppedReason.toString());
        }
        return i ;
    }

}
