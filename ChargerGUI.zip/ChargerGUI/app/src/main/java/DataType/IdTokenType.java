package DataType;

import EnumDataType.IdTokenEnumType;

import java.util.LinkedHashMap;
import java.util.Map;

public class IdTokenType {
    private static String idToken = null;
    private static IdTokenEnumType type = null ;


    public static void setIdToken(String idToken) {
        IdTokenType.idToken = idToken;
    }
    public static void setType(IdTokenEnumType type) {
        IdTokenType.type = type;
    }

    public static String getIdToken() {
        return idToken;
    }

    public static Map getp(){
        Map<String, String> m = new LinkedHashMap<String, String>(2);
        m.put("idToken",IdTokenType.idToken);
        m.put("type", IdTokenType.type.toString()) ;
        return m ;
    }
}
