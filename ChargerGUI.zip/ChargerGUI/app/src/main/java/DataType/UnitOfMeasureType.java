package DataType;

public class UnitOfMeasureType {
    String unit ;
    int multiplier ;
}
