package DataType;

import com.example.chargergui.dateTime;

import DataType.SampledValueType;

public class MeterValueType {
    dateTime timestamp ;
    SampledValueType sampledValue ;
}
