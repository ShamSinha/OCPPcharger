package ChargingStationResponse;

import org.json.JSONException;
import org.json.JSONObject;

public class CostUpdatedResponse {

    public JSONObject payload() throws JSONException {
        return null;
    }
}
