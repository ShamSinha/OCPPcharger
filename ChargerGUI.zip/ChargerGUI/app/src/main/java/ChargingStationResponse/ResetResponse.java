package ChargingStationResponse;

import org.json.JSONException;
import org.json.JSONObject;

import EnumDataType.ResetStatusEnumType;

public class ResetResponse {
    private ResetStatusEnumType status ;

    public ResetResponse(ResetStatusEnumType status) {
        this.status = status;
    }

    private ResetStatusEnumType getStatus() {
        return status;
    }

    public JSONObject payload() throws JSONException {
        JSONObject jo = new JSONObject();

        jo.put("status", getStatus().toString());
        return jo;
    }
}
