package ChargingStationResponse;

import DataType.GetVariableResultType;

public class GetVariablesResponse {
    private GetVariableResultType getVariableResult ;

    public GetVariablesResponse(GetVariableResultType getVariableResult) {
        this.getVariableResult = getVariableResult;
    }

    public GetVariableResultType getGetVariableResult() {
        return getVariableResult;
    }

}
