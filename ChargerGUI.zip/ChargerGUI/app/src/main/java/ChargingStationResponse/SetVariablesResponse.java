package ChargingStationResponse;

import DataType.SetVariableResultType;

public class SetVariablesResponse {
    SetVariableResultType setVariableResult ;

    public SetVariablesResponse(SetVariableResultType setVariableResult) {
        this.setVariableResult = setVariableResult;
    }

    public SetVariableResultType getSetVariableResult() {
        return setVariableResult;
    }

}
