package ChargingStationResponse;

import org.json.JSONException;
import org.json.JSONObject;

import EnumDataType.ChangeAvailabilityStatusEnumType;

public class ChangeAvailabilityResponse {

    private ChangeAvailabilityStatusEnumType status;

    public ChangeAvailabilityResponse(ChangeAvailabilityStatusEnumType status) {
        this.status = status;
    }

    public ChangeAvailabilityStatusEnumType getStatus() {
        return status;
    }
    public JSONObject payload() throws JSONException {
        JSONObject jo = new JSONObject();

        jo.put("status", this.getStatus().toString());
        return jo;
    }
}
