package ChargingStationResponse;

import org.json.JSONException;
import org.json.JSONObject;

import EnumDataType.GenericDeviceModelStatusEnumType;

public class GetBaseReportResponse {
    private GenericDeviceModelStatusEnumType status ;

    public GetBaseReportResponse(GenericDeviceModelStatusEnumType status) {
        this.status = status;
    }

    private GenericDeviceModelStatusEnumType getStatus() {
        return status;
    }

    public JSONObject payload() throws JSONException {
        JSONObject jo = new JSONObject();

        jo.put("status", this.getStatus().toString());
        return jo;
    }
}
