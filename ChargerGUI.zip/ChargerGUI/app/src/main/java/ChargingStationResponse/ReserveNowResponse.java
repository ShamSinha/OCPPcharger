package ChargingStationResponse;

public class ReserveNowResponse {
    
}
