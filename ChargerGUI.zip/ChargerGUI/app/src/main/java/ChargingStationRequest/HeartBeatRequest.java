package ChargingStationRequest;

import org.json.JSONException;
import org.json.JSONObject;


public class HeartBeatRequest {

    public static JSONObject payload() throws JSONException {
        return null;
    }
}
