package ChargingStationRequest;

import org.json.JSONException;
import org.json.JSONObject;

import EnumDataType.ReportBaseEnumType;

public class GetBaseReportRequest {
    private int requestId ;
    private ReportBaseEnumType reportBase ;

    public GetBaseReportRequest(int requestId, ReportBaseEnumType reportBase) {
        this.requestId = requestId;
        this.reportBase = reportBase;
    }

    private int getRequestId() {
        return requestId;
    }

    private ReportBaseEnumType getReportBase() {
        return reportBase;
    }

    public JSONObject payload() throws JSONException {
        JSONObject jo = new JSONObject();
        jo.put("requestId", getRequestId());
        jo.put("reportBase",getReportBase().toString());

        return jo;
    }
}
