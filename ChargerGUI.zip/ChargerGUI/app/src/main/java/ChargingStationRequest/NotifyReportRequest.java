package ChargingStationRequest;

import com.example.chargergui.dateTime2;

import org.json.JSONException;
import org.json.JSONObject;

import DataType.ReportDataType;

public class NotifyReportRequest {
    private int requestId;
    private String generatedAt;
    private int seqNo;
    private ReportDataType reportData;

    public NotifyReportRequest(int requestId, int seqNo, ReportDataType reportData) {
        this.requestId = requestId;
        this.seqNo = seqNo;
        this.reportData = reportData;
        setGeneratedAt();
    }

    private void setGeneratedAt() {
        dateTime2 dT = new dateTime2();
        this.generatedAt = dT.dateTime();
    }

    private int getRequestId() {
        return requestId;
    }

    private String getGeneratedAt() {
        return generatedAt;
    }

    private int getSeqNo() {
        return seqNo;
    }

    private ReportDataType getReportData() {
        return reportData;
    }

    public JSONObject payload() throws JSONException {
        JSONObject jo = new JSONObject();
        jo.put("requestId", getRequestId());
        jo.put("generatedAt", getGeneratedAt());
        jo.put("seqNo", getSeqNo());
        jo.put("reportData", getReportData());

        return jo;
    }
}