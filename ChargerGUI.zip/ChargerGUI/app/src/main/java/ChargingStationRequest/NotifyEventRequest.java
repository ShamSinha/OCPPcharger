package ChargingStationRequest;

import DataType.EventDataType;
import com.example.chargergui.dateTime2;

import org.json.JSONException;
import org.json.JSONObject;

public class NotifyEventRequest {
    private String generatedAt ;
    private Boolean tbc ;
    private int seqNO;
    private EventDataType eventData ;

    public NotifyEventRequest(Boolean tbc, int seqNO, EventDataType eventData) {
        this.tbc = tbc;
        this.seqNO = seqNO;
        this.eventData = eventData;
        setGeneratedAt();
    }

    private void setGeneratedAt() {
        dateTime2 dt = new dateTime2();
        this.generatedAt = dt.dateTime();
    }

    private String getGeneratedAt() {
        return this.generatedAt;
    }

    private Boolean getTbc() {
        return tbc;
    }

    private int getSeqNO() {
        return seqNO;
    }

    private EventDataType getEventData() {
        return eventData;
    }

    public JSONObject payload() throws JSONException {
        JSONObject jo = new JSONObject();

        jo.put("generatedAt",getGeneratedAt() );
        jo.put("tbc",getTbc());
        jo.put("seqNO", getSeqNO());
        jo.put("eventData", getEventData() );

        return jo;
    }
}
