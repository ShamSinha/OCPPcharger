package ChargingStationRequest;

import DataType.MeterValueType;

public class MeterValuesRequest {
    int evseId ;
    MeterValueType meterValue ;

}
